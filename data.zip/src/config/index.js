// # Exports env variables, constants

const fs = require("fs");
const path = require("path");
require("dotenv").config();

const keysPath = path.join(__dirname, "keys");
const privateKey = fs.readFileSync(path.join(keysPath, "private_key.pem"), "utf8");
const publicKey = fs.readFileSync(path.join(keysPath, "public_key.pem"), "utf8");

module.exports = {
    PORT: process.env.PORT || 3000,
    TOKEN: process.env.TOKEN || "EAAUyalZBUsakBPdXU5N4DhxzgGbOFsRlyVszd3ZB8TqRkYXkvXLvZCAhPBf3Io2LDE9bdvTiU4nwTwd46ur2Ehm3DUkMSdGqlbsIQW9Jld3Otbt5ucS30ysUS1jBNgXkH3q1nm0aZAAwf11pSHouRFWCI5ZAZC2SznGEBkL0Db9vwufYWXCjRCI6Gs7eLw41O5e2h8Nk5mGo6ZBaEYy1nPefPvH3PhWzKBFHMQUgicplQZDZD",
    PHONE_NUMBER_ID: process.env.PHONE_NUMBER_ID || "772137989315128",
    VERIFY_TOKEN: process.env.VERIFY_TOKEN || "my_secret_token",
    APPOINTMENT_FLOW_ID: process.env.APPOINTMENT_FLOW_ID || "1209029364594686",
    KYC_FLOW_ID: process.env.KYC_FLOW_ID || "1209029364594686",
    CHECK_STATUS_FLOW_ID: process.env.CHECK_STATUS_FLOW_ID || "1144368914259813",
    FLOW_NAME: process.env.FLOW_NAME || "EROC KYC FORM",
    privateKey,
    publicKey,
    FILES: {
        submissions: path.join(__dirname, "../data/submissions.json"),
        processedMessages: path.join(__dirname, "../data/processed_messages.json"),
    },
};
