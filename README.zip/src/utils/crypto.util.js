const crypto = require("crypto");
const { privateKey } = require("../config");

function decryptPayload(body) {
    try {
        const decryptedAesKey = crypto.privateDecrypt(
            {
                key: privateKey,
                padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                oaepHash: "sha256",
            },
            Buffer.from(body.encrypted_aes_key, "base64")
        );

        const decipher = crypto.createDecipheriv(
            "aes-256-cbc",
            decryptedAesKey,
            Buffer.from(body.initial_vector, "base64")
        );

        let decrypted = decipher.update(Buffer.from(body.encrypted_flow_data, "base64"));
        decrypted = Buffer.concat([decrypted, decipher.final()]);

        return JSON.parse(decrypted.toString("utf8"));
    } catch (err) {
        console.error("❌ Decryption failed:", err.message);
        throw err;
    }
}

module.exports = { decryptPayload };
