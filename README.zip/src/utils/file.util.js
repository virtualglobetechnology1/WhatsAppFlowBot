const fs = require("fs");

function initializeJsonFile(filePath, defaultValue = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultValue, null, 2));
        console.log(`📁 Created ${filePath}`);
    }
}

function readJson(filePath) {
    try {
        if (!fs.existsSync(filePath)) {
            console.warn(`⚠️ File not found: ${filePath}, creating new one.`);
            fs.writeFileSync(filePath, "[]", "utf8"); // default empty array
            return [];
        }

        const data = fs.readFileSync(filePath, "utf8").trim();

        if (!data) {
            console.warn(`⚠️ File empty: ${filePath}, using empty array.`);
            return [];
        }

        return JSON.parse(data);
    } catch (err) {
        console.error(`❌ Error reading file ${filePath}: ${err.message}`);
        return [];
    }
}

function writeJson(filePath, data) {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    } catch (err) {
        console.error("❌ Error writing file:", err);
    }
}

module.exports = { initializeJsonFile, readJson, writeJson };
