const express = require("express");
const { getSubmissions, handleKycSubmission } = require("../controllers/submission.controller");

const router = express.Router();

// GET all submissions
router.get("/", getSubmissions);
router.post("/kyc", handleKycSubmission);

module.exports = router;
