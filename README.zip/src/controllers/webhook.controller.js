const { VERIFY_TOKEN } = require("../config");
const { isMessageProcessed, markMessageAsProcessed } = require("../services/dedup.service");
const { sendServicesMenu, sendServiceNextMenu, sendText, sendKycFlow } = require("../services/whatsapp.service");
const { saveSubmission } = require("../services/submission.service");

exports.verifyWebhook = (req, res) => {
    console.log("🔍 Verifying webhook...");
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    if (mode && token && mode === "subscribe" && token === VERIFY_TOKEN) {
        console.log("WEBHOOK_VERIFIED");
        return res.status(200).send(challenge);
    }
    res.sendStatus(403);
};

exports.handleWebhook = async (req, res) => {
    try {
        const messages = req.body.entry?.[0]?.changes?.[0]?.value?.messages;
        if (!messages) return res.sendStatus(200);

        const message = messages[0];
        const from = message.from;
        const messageId = message.id;

        if (isMessageProcessed(messageId)) return res.sendStatus(200);

        if (message.text?.body) {
            const text = message.text.body.toLowerCase().trim();
            if (["hi", "hello"].includes(text)) {
                console.log(`👋 Greeting received from ${from}`);
                await sendServicesMenu(from);
                markMessageAsProcessed(messageId);
            }
        } else if (message.interactive?.type === "list_reply") {
            await sendServiceNextMenu(from, message.interactive.list_reply.title);
            markMessageAsProcessed(messageId);
        }
        else if (message.interactive?.type === "button_reply") {
            const buttonId = message.interactive.button_reply.id;

            if (buttonId === "fill_kyc") {
                // Trigger the KYC flow
                await sendKycFlow(from);
            } else if (buttonId === "check_status") {
                await sendText(from, "📌 Please provide your reference number to check status.");
            }

            markMessageAsProcessed(messageId);
        }
        else if (message.interactive?.type === "nfm_reply") {
            saveSubmission(from, message.interactive?.nfm_reply?.response_json);
            await sendText(from, "✅ Thank you! Your appointment request has been received.");
            markMessageAsProcessed(messageId);
        } else {
            markMessageAsProcessed(messageId);
        }
        res.sendStatus(200);
    } catch (err) {
        console.error("❌ Webhook error:", err);
        res.sendStatus(200);
    }
};
