const { getAllSubmissions } = require("../services/submission.service");

// GET /submissions
function getSubmissions(req, res) {
    try {
        const submissions = getAllSubmissions();
        res.json(submissions);
    } catch (err) {
        console.error("❌ Error fetching submissions:", err.message);
        res.status(500).json({ error: "Failed to fetch submissions" });
    }
}
function handleKycSubmission(req, res) {
    try {
        const body = req.body;

        if (body.entry) {
            body.entry.forEach(entry => {
                entry.changes.forEach(change => {
                    if (change.value && change.value.messages) {
                        const msg = change.value.messages[0];

                        if (msg.type === "interactive" && msg.interactive.type === "flow") {
                            console.log("📥 Received KYC Submission:", msg.interactive.response_json);

                            // 👉 Save to DB here
                            // Example: KycModel.create(msg.interactive.response_json);
                        }
                    }
                });
            });
        }

        res.sendStatus(200);
    } catch (err) {
        console.error("❌ handleKycSubmission error:", err);
        res.sendStatus(500);
    }
};
module.exports = { getSubmissions, handleKycSubmission };
