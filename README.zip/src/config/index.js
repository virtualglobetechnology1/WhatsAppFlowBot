// # Exports env variables, constants

const fs = require("fs");
const path = require("path");
require("dotenv").config();

const keysPath = path.join(__dirname, "keys");
const privateKey = fs.readFileSync(path.join(keysPath, "private_key.pem"), "utf8");
const publicKey = fs.readFileSync(path.join(keysPath, "public_key.pem"), "utf8");

module.exports = {
    PORT: process.env.PORT || 3000,
    TOKEN: process.env.TOKEN || "EAAUyalZBUsakBPQyDCi7ObWiZAys7VYY5sWpOoBzepK8KGTn6ZASw0edTr8XsqsIQ1hy6QRIYZBqOYBwEHB9ZAAWo3VNXNal9ly7Kpq1L4d5ufhFlds2RCOPcraJzJ9udBpSvPjNiKBlOk669HIb2vZAYzdLmotvhiZCY0bbF70TDmNnZAj8rLZCamqtviZBoNOH2Dv9RKI2nDh7XyVRi4PYWApSqpcAvjtCRFa48JvNIqWQZDZD",
    PHONE_NUMBER_ID: process.env.PHONE_NUMBER_ID || "772137989315128",
    VERIFY_TOKEN: process.env.VERIFY_TOKEN || "my_secret_token",
    APPOINTMENT_FLOW_ID: process.env.APPOINTMENT_FLOW_ID || "1209029364594686",
    KYC_FLOW_ID: process.env.KYC_FLOW_ID || "1209029364594686",
    FLOW_NAME: process.env.FLOW_NAME || "EROC KYC FORM",
    privateKey,
    publicKey,
    FILES: {
        submissions: path.join(__dirname, "../data/submissions.json"),
        processedMessages: path.join(__dirname, "../data/processed_messages.json"),
    },
};
